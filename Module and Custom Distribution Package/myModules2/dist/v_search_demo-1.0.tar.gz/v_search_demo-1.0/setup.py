from setuptools import setup

setup(
    name='v_search_demo',   # most important argument 1
    version='1.0',
    description='Search tools',
    author='Random',
    author_email='random@gmail.com',
    url='random.com',
    py_modules=['v_search_demo']   # most important argument 2
)
