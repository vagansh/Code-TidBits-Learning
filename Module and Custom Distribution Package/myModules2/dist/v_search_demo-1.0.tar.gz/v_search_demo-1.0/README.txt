The package searches for :
1. vowels in an input sentence. (search4vowels)
2. user-given letters in an input sentence. (search4letters)